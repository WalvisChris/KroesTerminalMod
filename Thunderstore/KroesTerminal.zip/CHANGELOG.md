# 1.0.4  
- added `kenemy` command.  
- changed `kitems` command.  

# 1.0.3  
- fixed quotaUI scaling because of race conditions.  
- added CHANGELOG (for thunderstore).  

# 1.0.2
- README and manifest update. 

# 1.0.1  
- README and manifest update.  

# 1.0.0  
- This is the initial version.  