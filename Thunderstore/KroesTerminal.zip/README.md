# KroesTerminal v1.0.4  
Extra Terminal commands & UI elements.   

# Custom Terminal Commands  
**kscan**: detailed moon scrap scan.  
**kitems**: scan items on moon, in ship and in elevators.  
**kenemy**: scan inside and outside enemies.  

# Extra features
Quota UI  